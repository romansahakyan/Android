package com.herokuapp.romanweb1.finalapp;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

/**
 * Created by specialadmin on 2/22/18.
 */
public class SearchData extends Activity implements Button.OnClickListener {
    ImageButton search;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        search =(ImageButton)findViewById(R.id.imbt1);
        search.setOnClickListener(this);

    }
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.imbt1:
                try {
                    ConnectService();
                } catch (Exception e) {

                    e.printStackTrace();
                }
                break;
        }
    }


}
